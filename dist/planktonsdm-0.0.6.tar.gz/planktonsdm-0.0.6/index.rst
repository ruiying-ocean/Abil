planktonsdm docs
=======================================
This is a set of tools to build and process species distributions models in Python.

Currently supports:

Classifiers:
``RandomForestClassifier``
``KNeighborsClassifier``
``XGBClassifier``

Regressors:
``RandomForestRegressor`` 
``KNeighborsRegressor``
``XGBRegressor``

Configuration:
``1-phase`` or ``2-phase``

Transformations: ``y log-transform`` and ``X normalization``

Predictions:
``single model`` and weighted ``ensembles``

 
    
.. toctree::
   /docs/installation
   /docs/configuration
   /docs/example
   /docs/tune
   /docs/predict
   /docs/post
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
