#!/bin/bash
#
#
# This is a SLURM script to tune planktonSDM models embarrassingly parallel
# To run the script singularity and SLURM are required
# For more info see the README:
# https://github.com/nanophyto/planktonSDM/README.rmd
#
#
#SBATCH --time=0-6:00:00
#SBATCH --nodes=1
#SBATCH --mem=10000M
#SBATCH --cpus-per-task=16
#SBATCH --array=0-41
#SBATCH --account=GEOG024542

#define arguments:
i=${SLURM_ARRAY_TASK_ID}
path=${/$(whoami)/planktonSDM/}
model=${knn}

#load singularity
module  load apps/singularity/1.1.3 lib/openmpi/4.0.2-gcc.4.8.5 

#run scripts using singularity container:
srun singularity exec \
-B/user/work/$(whoami):/user/work/$(whoami) \
/user/work/$(whoami)/planktonSDM/planktonSDM.sif \
python /user/work/$(whoami)/planktonSDM/deVries2023/python/tune_KNN.py ${SLURM_CPUS_PER_TASK} ${i} ${path} ${model}

#export cache for debugging:
export SINGULARITY_CACHEDIR=/user/work/$(whoami)/.singularity