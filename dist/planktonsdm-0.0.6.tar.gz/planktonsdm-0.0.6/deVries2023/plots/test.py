import matplotlib.pyplot as plt
import xarray as xr
import seaborn as sns
import numpy as np
import pandas as pd
from scipy.stats import wasserstein_distance
from sklearn.preprocessing import StandardScaler
import pickle

test = pickle.load(open("/home/phyto/CoccoML/predictions/merged/rf/scoring/Coccolithus pelagicus_clf.sav", 'rb'))


print("fin")
    def clean_devries2021(): 

        d = pd.read_table("/home/phyto/CoccoML/data/abundances/deVries-etal_2020.csv")

        d['Date/Time'] = pd.to_datetime(d['Date/Time'])

        d = d[d.Reference != 'Takahashi & Okada (2000)'] #wrong data
        d = d[d.Reference != 'Godrijan et al. (2018)'] #shallow med
        d = d[d.Reference != 'Luan et al. (2016)'] #shallow china sea
        d = d[d.Reference != 'Cerino et al. (2017)'] #shallow med

        d.rename(columns = {'Depth water [m]':'Depth'}, inplace = True)

        #remove samples below 200m (9 samples)
        d = d[d.Depth <= 201] 


        #Saavedra-Pellitero et al. (2014) samples:
        #weirdly lablled lon

        d = d.replace(-182.73, 2.73)
        d = d.replace(-182.85, 2.85)
        d = d.replace(-185.47, 5.47)

        d.rename(columns=new_names, inplace=True)

        d = d.groupby(by=d.columns, axis=1).sum()

        d.loc[d["Reference"] == "Saavedra-Pellitero et al. (2014)", "Gephyrocapsa ericsonii"] = 0


        d['Month'] = pd.DatetimeIndex(d['Date/Time']).month
        d['Year'] = pd.DatetimeIndex(d['Date/Time']).year
        d.drop(columns=['Date/Time',"Sample method"], inplace=True)

        d.rename(columns = {'Depth water [m]':'Depth'}, inplace = True)

        d['Method'] = "SEM"

        d = d.set_index(['Latitude', 'Longitude', 'Depth', 'Month', 'Year', 'Reference', 'Method'])


        return(d)