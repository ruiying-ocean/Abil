import pandas as pd
import numpy as np
import glob, os
import xarray as xr
import pickle

if 'site-packages' in __file__:
    from planktonsdm.diversity import diversity
else:
    from diversity import diversity

class post:
    """
    Post processing of SDM
    """
    def __init__(self, model_config):

        def merge_netcdf(path_in):
            print("merging...")
            ds = xr.merge([xr.open_dataset(f) for f in glob.glob(os.path.join(path_in, "*.nc"))])
            return(ds)
        
        if model_config['hpc']==False:
            self.path_out = model_config['local_root'] + model_config['path_out'] 
            self.ds = merge_netcdf(model_config['local_root'] + model_config['path_in'] )
            self.traits = pd.read_csv(model_config['local_root'] + model_config['traits'])
            self.env_data_path =  model_config['local_root'] + model_config['env_data_path']
            self.root  =  model_config['local_root'] 

        elif model_config['hpc']==True:
            self.path_out = model_config['hpc_root'] + model_config['path_out'] 
            self.ds = merge_netcdf(model_config['hpc_root'] + model_config['path_in'] )   
            self.traits = pd.read_csv(model_config['hpc_root'] + model_config['traits'])
            self.env_data_path =  model_config['hpc_root'] + model_config['env_data_path']
            self.root  =  model_config['hpc_root'] 

        else:
            raise ValueError("hpc True or False not defined in yml")
            

        self.d = self.ds.to_dataframe()
        self.d = self.d.dropna()
        self.ds = None
        self.species = self.d.columns.values
        self.model_config = model_config

    def merge_performance(self, model, configuration=None):
        
        all_performance = []

        if model=="ens":
            extension = ".sav"
        else:
            extension = "_" + configuration + ".sav"

        for i in range(len(self.d.columns)):
            
            m = pickle.load(open(self.root + self.model_config['path_out'] + model + "/scoring/" + self.d.columns[i] + extension, 'rb'))
            R2 = np.mean(m['test_R2'])
            RMSE = np.mean(m['test_RMSE'])
            MAE = np.mean(m['test_MAE'])
            species = self.d.columns[i]
            performance = pd.DataFrame({'species':[species], 'R2':[R2], 'RMSE':[RMSE], 'MAE':[MAE]})
            all_performance.append(performance)

        all_performance = pd.concat(all_performance)

        if configuration==None:
            all_performance.to_csv(self.root + self.model_config['path_out'] + model + "_performance.csv", index=False)
        else:
            all_performance.to_csv(self.root + self.model_config['path_out'] + model + "_" + configuration + "_performance.csv", index=False)
        
        print("finished merging performance")

    def merge_parameters(self, model):
        
        all_parameters = []

        for i in range(len(self.d.columns)):
            
            species = self.d.columns[i]

            m = pickle.load(open(self.root + self.model_config['path_out'] + model + "/model/" + self.d.columns[i] + "_reg.sav", 'rb'))
            # score_reg = np.mean(m['test_MAE'])

            # m = pickle.load(open(self.root + self.model_config['path_out'] + model + "/scoring/" + self.d.columns[i] + "_zir.sav", 'rb'))
            # score_zir = np.mean(m['test_MAE'])

            # if score_reg > score_zir:
            #     m = pickle.load(open(self.root + self.model_config['path_out'] + model + "/model/" + self.d.columns[i] + "_reg.sav", 'rb'))
            # elif score_reg < score_zir:
            #     m = pickle.load(open(self.root + self.model_config['path_out'] + model + "/model/" + self.d.columns[i] + "_reg.sav", 'rb'))

            if model == "rf":
                max_depth = m.regressor_.named_steps.estimator.max_depth
                max_features = m.regressor_.named_steps.estimator.max_features
                max_samples = m.regressor_.named_steps.estimator.max_samples
                parameters = pd.DataFrame({'species':[species], 'max_depth':[max_depth], 'max_features':[max_features], 'max_samples':[max_samples]})
                all_parameters.append(parameters)
            elif model == "xgb":
                max_depth = m.regressor_.named_steps.estimator.max_depth
                subsample = m.regressor_.named_steps.estimator.subsample
                colsample_bytree = m.regressor_.named_steps.estimator.colsample_bytree

                learning_rate = m.regressor_.named_steps.estimator.learning_rate
                alpha = m.regressor_.named_steps.estimator.reg_alpha

                parameters = pd.DataFrame({'species':[species], 'max_depth':[max_depth], 'subsample':[subsample], 'colsample_bytree':[colsample_bytree],
                                           'learning_rate':[learning_rate], 'alpha':[alpha]                                           
                                           })
                all_parameters.append(parameters)
            elif model == "knn":
                max_features = m.regressor_.named_steps.estimator.max_features
                max_samples = m.regressor_.named_steps.estimator.max_samples

                leaf_size = m.regressor_.named_steps.estimator.estimator.leaf_size
                n_neighbors = m.regressor_.named_steps.estimator.estimator.n_neighbors
                p = m.regressor_.named_steps.estimator.estimator.p
                weights = m.regressor_.named_steps.estimator.estimator.weights

                parameters = pd.DataFrame({'species':[species], 'max_features':[max_features], 'max_samples':[max_samples],
                                           'leaf_size':[leaf_size], 'p':[p], 'n_neighbors':[n_neighbors], 'weights':[weights]
                                           })
                all_parameters.append(parameters)    

        all_parameters= pd.concat(all_parameters)
        all_parameters.to_csv(self.root + self.model_config['path_out'] + model + "_parameters.csv", index=False)
        
        print("finished merging parameters")



    def estimate_carbon(self, variable):

        """
        Estimate carbon content for each species


        Parameters
        ----------

        variable: string
            carbon content to estimate

        """


        w = self.traits.query('species in @self.species')
        var = w[variable].to_numpy()
        print(var)
        self.d = self.d.apply(lambda row : (row[self.species]* var), axis = 1)
        print("finished estimating " + variable)


    def def_groups(self, dict):
        """
        Define groups of species

        Parameters
        ----------

        dict: dictionary
        A dictionary containing group definitions


        """
                

        df = self.d[self.species]
        df = (df.rename(columns=dict)
            .groupby(level=0, axis=1, dropna=False)).sum( min_count=1)
        self.d = pd.concat([self.d, df], axis=1)
        print("finished defining groups")

    def cwm(self, variable):
        """
        Calculate community weighted mean values for a given parameter. 

        Parameters
        ----------

        variable: string
            variable that is used to estimate cwm.

        """

        w = self.traits.query('species in @self.species')
        var = w[variable].to_numpy()
        var_name = 'cwm ' + variable
        self.d[var_name] = self.d.apply(lambda row : np.average(var, weights=row[self.species]), axis = 1)
        print("finished calculating CWM " + variable)

    def richness(self, metric):
        measure = diversity(metric, self.d[self.species].clip(lower=1))
        self.d[metric] = measure.values
        print("finished calculating " + metric)

    def total(self):
        """
        Calculate total

        Notes
        ----------

        Total is estimated based on the species list defined in model_config. Other species or groupings are excluded from the summation. 

        """

        self.d['total'] = self.d[self.species].sum( axis='columns')
        self.d['total_log'] = np.log(self.d['total'])
        print("finished calculating total")

    def merge_env(self, X_predict):
        """
        Merge model output with environmental data 
        """

        self.d = pd.concat([self.d, X_predict], axis=1)

    def return_d(self):
        return(self.d)

    def export_ds(self, file_name):
        """
        Export processed dataset to netcdf.

        Parameters
        ----------
        file_name: name netcdf will be saved as. 

        Notes
        ----------
        data export location is defined in the model_config.yml

        """

    
        try: #make new dir if needed
            os.makedirs(self.path_out)
        except:
            None
    
        ds = self.d.to_xarray()

        print(self.d.head())
        ds.to_netcdf(self.path_out + file_name + ".nc")
        print("exported ds to: " + self.path_out + file_name + ".nc")
        #add nice metadata


    def export_csv(self, file_name):
        """
        Export processed dataset to csv.

        Parameters
        ----------
        file_name: name csv will be saved as. 

        Notes
        ----------
        data export location is defined in the model_config.yml

        """
    
        try: #make new dir if needed
            os.makedirs(self.path_out)
        except:
            None
    
        print(self.d.head())
        self.d.to_csv(self.path_out + file_name + ".csv")
        print("exported d to: " + self.path_out + file_name + ".csv")
        #add nice metadata
