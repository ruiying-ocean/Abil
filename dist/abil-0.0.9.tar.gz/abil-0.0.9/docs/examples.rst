Examples
==========

.. include:: classifier-ensemble.rst
.. include:: regressor-ensemble.rst



