import pandas as pd



targets = ['Emiliania huxleyi', 'Coccolithus pelagicus']

traits = pd.read_csv("/home/phyto/Abil/devries2024/data/traits.csv")

w = traits.query('Target in @targets')

variable = 'pg pic'
var = w[variable].to_numpy()


print("fiml")