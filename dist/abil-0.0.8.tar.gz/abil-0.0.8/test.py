import pandas as pd

d = pd.read_csv("/home/phyto/Abil/data/training_old.csv")
d = d[["lat", "lon", "depth", "time", 
        "Emiliania huxleyi", "Coccolithus pelagicus",
        "Florisphaera profunda", "temperature", "si",
        "phosphate", "din", "irradiance", "FID"]]
d.dropna(inplace=True, subset="din")

d.to_csv("/home/phyto/Abil/data/training.csv", index=False)

