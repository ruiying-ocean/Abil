from sklearn.linear_model import LogisticRegression
import numpy as np
import pandas as pd

from yaml import load
from yaml import CLoader as Loader
import xarray as xr


ds = xr.open_dataset("/home/phyto/CoccoML/ModelOutput/ens/predictions/Emiliania huxleyi.nc")

d =ds.to_dataframe()

print(np.min(d['ci32']))

print("fin")