from sklearn.linear_model import LogisticRegression
import numpy as np
import pandas as pd
from yaml import load
from yaml import CLoader as Loader
import xarray as xr
import pickle

log = False


def merge_performance(d, species_list, root, model, configuration=None):
    
    all_performance = []

    if model=="ens":
        extension = ".sav"
    else:
        extension = "_" + configuration + ".sav"

    for i in range(len(species_list)):
        species = species_list.iloc[i][0]
        m = pickle.load(open(root + species + extension, 'rb'))
        mean = np.mean(d[species])
        n = len(d[species][d[species]>0])
        R2 = np.mean(m['test_R2'])
        RMSE = -1*np.mean(m['test_RMSE'])
        MAE = -1*np.mean(m['test_MAE'])
        rRMSE = -1*np.mean(m['test_RMSE'])/mean
        rMAE = -1*np.mean(m['test_MAE'])/mean            
        performance = pd.DataFrame({'species':[species], 'R2':[R2], 'RMSE':[RMSE], 'MAE':[MAE],
                                    'rRMSE':[rRMSE], 'rMAE':[rMAE], 'n':[n]})
        all_performance.append(performance)

    all_performance = pd.concat(all_performance)

    if configuration==None:
        all_performance.to_csv(root + model + "_performance.csv", index=False)
    else:
        all_performance.to_csv(root + configuration + "_performance.csv", index=False)
    
    print("finished merging performance")

d =  pd.read_csv("/home/phyto/planktonSDM/devries2024/data/obs_env.csv")
species_list = pd.read_csv("/home/phyto/planktonSDM/devries2024/data/SDM_species.csv")


merge_performance(d, species_list, 
                  root ="/home/phyto/planktonSDM/ModelOutput/xgb/scoring/", 
                  model = "XGB", 
                  configuration="reg")




print("fin")