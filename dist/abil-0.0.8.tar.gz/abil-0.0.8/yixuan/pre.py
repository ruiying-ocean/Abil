import pandas as pd
import numpy as np
import glob, os
import xarray as xr


def merge_obs_env(obs_path = "../data/gridded_abundances.csv",
                  env_path = "../data/env_data.nc",
                  env_vars = ["temperature", "si", 
                              "phosphate", "din", 
                              "o2", "mld", "DIC", 
                              "TA", "irradiance", 
                              "chlor_a","Rrs_547",
                              "Rrs_667","CI_2",
                              "pic","si_star",
                              "si_n","FID", 
                              "time", "depth", 
                              "lat", "lon"],
                    out_path = "../data/obs_env.csv"):

    d = pd.read_csv(obs_path)

    d = d.convert_dtypes()

    d = d.groupby(['Latitude', 'Longitude', 'Depth', 'Month']).mean().reset_index()
    d.rename({'Latitude':'lat','Longitude':'lon','Depth':'depth','Month':'time'},inplace=True,axis=1)
    d.set_index(['lat', 'lon', 'depth', 'time'], inplace=True)

    print("loading env")

    ds = xr.open_dataset(env_path)
    print("converting to dataframe")
    df = ds.to_dataframe()
    ds = None 
    df.reset_index(inplace=True)
    df = df[env_vars]
    df.set_index(['lat','lon','depth','time'],inplace=True)
    print("merging environment")

    out = d.merge(df, how="left", left_index=True, right_index=True)
    out.to_csv(out_path, index=True)
    print("fin")



d = merge_obs_env(obs_path = "/home/phyto/planktonSDM/data/gridded_observations.csv",
                  env_path= '/home/phyto/planktonSDM/data/env_data.nc',
                  env_vars = ["temperature", "si", 
                              "phosphate", "din", 
                              "o2", "mld", "DIC", 
                              "TA", "irradiance", 
                              "chlor_a","Rrs_547",
                              "Rrs_667", "pic", "FID", 
                              "time", "depth", 
                              "lat", "lon"],
                    out_path = "/home/phyto/planktonSDM/data/obs_env.csv")


print("fin")
