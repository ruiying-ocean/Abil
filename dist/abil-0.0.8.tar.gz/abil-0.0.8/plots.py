import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

d = pd.read_csv("/home/phyto/planktonSDM/ModelOutput/xgb/scoring/reg_performance.csv")
d.set_index(['species'], inplace=True)

#sns.scatterplot(y=d['n'], x=d['R2'])
#plt.show()


d =  d[['R2', 'rRMSE', 'rMAE']]

#sns.heatmap(d)
#plt.show()


d.reset_index(inplace=True)
d = d.melt(id_vars=['species'])
g = sns.FacetGrid(d, row="variable", sharey=False)
g.map_dataframe(sns.barplot, x="species", y="value")
plt.show()
